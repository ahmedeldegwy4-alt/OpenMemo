# OpenMemo

Open-source voice recorder for Android that turns speech into text **on the phone itself** — no account, no subscription, no upload.
An open alternative to apps like iMemo.

تطبيق مفتوح المصدر لتسجيل الصوت وتحويله لنص على الموبايل نفسه.
من غير حساب، ومن غير اشتراك، والصوت ما بيخرجش من جهازك.

## Features

- Record lectures and meetings (keeps recording with the screen off, pause/resume).
- Offline speech-to-text with [whisper.cpp](https://github.com/ggml-org/whisper.cpp) — Arabic, English and ~100 other languages.
- Timestamps per line, editable transcript, search across all recordings.
- Import any audio/video file (mp3, m4a, ogg/opus, WhatsApp voice notes via *Share → OpenMemo*).
- Share or copy text, share audio as WAV.
- Arabic and English interface (follows the phone language), light and dark mode.

## Speech models

Downloaded once from inside the app (Settings), then everything is offline:

| Model | Size | Notes |
|---|---|---|
| tiny (q5_1) | ~32 MB | fastest, lowest accuracy |
| base (q5_1) | ~57 MB | good for English |
| small (q5_1) | ~182 MB | recommended for Arabic |

You can also import any whisper.cpp `ggml-*.bin` model file from the phone storage.
Choosing the spoken language in Settings (instead of Auto) improves accuracy.

## Build the APK (no Android Studio needed)

The repository builds itself on GitHub Actions:

1. Create a new repository on GitHub and push this folder to it.
2. Open the **Actions** tab — the *Build APK* workflow runs automatically (about 10–15 minutes).
3. Open **Releases** on the repository page and download `OpenMemo-N.apk` on your phone.
4. Install it (allow "Install unknown apps" for your browser when asked).

```bash
cd OpenMemo
git init -b main
git add .
git commit -m "OpenMemo first version"
git remote add origin https://github.com/YOUR_USER/OpenMemo.git
git push -u origin main
```

Local build instead: open the folder in Android Studio (Koala or newer, with NDK and CMake 3.22.1 installed) and run *Build → Build APK(s)*.

## Project layout

```
app/src/main/java/org/openmemo/app/
  MainActivity.kt        list, search, record button, import
  DetailActivity.kt      player, transcript editor, share
  SettingsActivity.kt    language, models, options
  RecorderService.kt     16 kHz WAV recording (foreground service)
  TranscribeService.kt   import + transcription queue (foreground service)
  AudioImporter.kt       decode any audio to 16 kHz mono
  Core.kt                storage, models, WAV, whisper bridge
app/src/main/cpp/
  whisper_jni.cpp        JNI bridge
  whisper.cpp/           vendored whisper.cpp 1.8.5 (CPU backend only, MIT)
```

## Not included yet

- AI summaries (needs a local LLM or an online API — planned as an optional add-on).
- Speaker identification.

## License

MIT. whisper.cpp and the Whisper models are MIT licensed.
