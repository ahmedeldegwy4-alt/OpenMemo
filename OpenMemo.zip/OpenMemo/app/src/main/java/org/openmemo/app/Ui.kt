package org.openmemo.app

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Tiny helpers to build the UI in code (no XML layouts, fewer moving parts). */

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.vbox(pad: Int = 16): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
}

fun Context.hbox(): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.HORIZONTAL
    gravity = Gravity.CENTER_VERTICAL
}

fun Context.text(s: String, size: Float = 16f, bold: Boolean = false): TextView = TextView(this).apply {
    text = s
    textSize = size
    if (bold) setTypeface(typeface, Typeface.BOLD)
    textAlignment = View.TEXT_ALIGNMENT_VIEW_START
}

fun Context.pill(color: Int, radiusDp: Int = 28): GradientDrawable = GradientDrawable().apply {
    setColor(color)
    cornerRadius = dp(radiusDp).toFloat()
}

fun Context.button(label: String, color: Int = getColor(R.color.brand), onClick: () -> Unit): Button =
    Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = pill(color, 12)
        backgroundTintList = ColorStateList.valueOf(color)
        setPadding(dp(16), dp(10), dp(16), dp(10))
        setOnClickListener { onClick() }
    }

fun lp(w: Int = ViewGroup.LayoutParams.MATCH_PARENT, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT, weight: Float = 0f) =
    LinearLayout.LayoutParams(w, h, weight)

fun LinearLayout.LayoutParams.margins(c: Context, all: Int): LinearLayout.LayoutParams = apply {
    val m = c.dp(all); setMargins(m, m, m, m)
}

fun Context.displayName(uri: Uri): String {
    try {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0)?.let { return it }
        }
    } catch (_: Exception) {}
    return uri.lastPathSegment ?: "audio"
}

fun Context.statusLabel(m: Memo): String = when (m.status) {
    Status.QUEUED -> tr("في الانتظار", "Queued")
    Status.WORKING -> tr("جاري التحويل…", "Transcribing…")
    Status.DONE -> tr("تم ✓", "Done ✓")
    Status.ERROR -> tr("خطأ: ", "Error: ") + m.error
    else -> tr("بدون نص", "Not transcribed")
}
