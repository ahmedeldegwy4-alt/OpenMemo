package org.openmemo.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import org.json.JSONObject
import java.io.File
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.floor

// ---------------------------------------------------------------- whisper.cpp

interface ProgressListener {
    fun onProgress(percent: Int)
}

object WhisperLib {
    init {
        System.loadLibrary("openmemo")
    }

    @JvmStatic external fun nativeInit(modelPath: String): Long
    @JvmStatic external fun nativeFree(ctx: Long)
    @JvmStatic external fun nativeSetAbort(value: Boolean)
    @JvmStatic external fun nativeSystemInfo(): String
    @JvmStatic external fun nativeTranscribe(
        ctx: Long, samples: FloatArray, language: String, threads: Int,
        offsetMs: Long, timestamps: Boolean, listener: ProgressListener?
    ): ByteArray?
}

// ---------------------------------------------------------------- helpers

fun Context.isArabic(): Boolean = resources.configuration.locales[0].language == "ar"
fun Context.tr(ar: String, en: String): String = if (isArabic()) ar else en

fun formatDuration(ms: Long): String {
    val s = ms / 1000
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
    else String.format(Locale.US, "%02d:%02d", m, sec)
}

fun formatDate(t: Long): String =
    SimpleDateFormat("yyyy-MM-dd  HH:mm", Locale.US).format(Date(t))

const val CHANNEL_ID = "openmemo_work"

fun ensureChannel(ctx: Context) {
    val nm = ctx.getSystemService(NotificationManager::class.java)
    if (nm.getNotificationChannel(CHANNEL_ID) == null) {
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "OpenMemo", NotificationManager.IMPORTANCE_LOW)
        )
    }
}

// ---------------------------------------------------------------- settings

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("openmemo", Context.MODE_PRIVATE)

    /** "auto", "ar", "en" or any whisper language code */
    fun language(c: Context): String = sp(c).getString("lang", "auto") ?: "auto"
    fun setLanguage(c: Context, v: String) = sp(c).edit().putString("lang", v).apply()

    fun model(c: Context): String? = sp(c).getString("model", null)
    fun setModel(c: Context, file: String?) = sp(c).edit().putString("model", file).apply()

    fun autoTranscribe(c: Context): Boolean = sp(c).getBoolean("auto", true)
    fun setAutoTranscribe(c: Context, v: Boolean) = sp(c).edit().putBoolean("auto", v).apply()

    fun timestamps(c: Context): Boolean = sp(c).getBoolean("ts", true)
    fun setTimestamps(c: Context, v: Boolean) = sp(c).edit().putBoolean("ts", v).apply()
}

// ---------------------------------------------------------------- models

data class ModelInfo(val file: String, val labelAr: String, val labelEn: String, val sizeMb: Int) {
    val url get() = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/$file"
}

object Models {
    val list = listOf(
        ModelInfo("ggml-tiny-q5_1.bin", "صغير جدًا — أسرع، دقة أقل", "Tiny — fastest, lower accuracy", 32),
        ModelInfo("ggml-base-q5_1.bin", "أساسي — متوازن (مقترح للإنجليزي)", "Base — balanced", 57),
        ModelInfo("ggml-small-q5_1.bin", "متوسط — أدق للعربي (مقترح)", "Small — best for Arabic (recommended)", 182),
    )

    fun dir(c: Context) = File(c.filesDir, "models").apply { mkdirs() }
    fun file(c: Context, name: String) = File(dir(c), name)
    fun installed(c: Context): List<File> =
        dir(c).listFiles { f -> f.isFile && f.name.endsWith(".bin") }?.sortedBy { it.name } ?: emptyList()

    /** Current model file, or the first installed one, or null. */
    fun active(c: Context): File? {
        Prefs.model(c)?.let { val f = file(c, it); if (f.exists()) return f }
        return installed(c).firstOrNull()?.also { Prefs.setModel(c, it.name) }
    }

    /** Blocking download with progress (0..100). Returns null on success or an error message. */
    fun download(c: Context, m: ModelInfo, cancelled: () -> Boolean, progress: (Int) -> Unit): String? {
        val part = File(dir(c), m.file + ".part")
        try {
            var url = URL(m.url)
            var conn = url.openConnection() as HttpURLConnection
            var redirects = 0
            while (true) {
                conn.instanceFollowRedirects = false
                conn.connectTimeout = 20000
                conn.readTimeout = 30000
                val code = conn.responseCode
                if (code in 300..399 && redirects < 5) {
                    url = URL(url, conn.getHeaderField("Location"))
                    conn.disconnect()
                    redirects++
                    conn = url.openConnection() as HttpURLConnection
                    continue
                }
                if (code != 200) return "HTTP $code"
                break
            }
            val total = conn.contentLengthLong
            conn.inputStream.use { input ->
                part.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    var done = 0L
                    var last = -1
                    while (true) {
                        if (cancelled()) return "cancelled"
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        if (total > 0) {
                            val p = (done * 100 / total).toInt()
                            if (p != last) { last = p; progress(p) }
                        }
                    }
                }
            }
            val dst = file(c, m.file)
            if (!part.renameTo(dst)) return "rename failed"
            if (Prefs.model(c) == null) Prefs.setModel(c, m.file)
            return null
        } catch (e: Exception) {
            return e.message ?: e.toString()
        } finally {
            if (part.exists()) part.delete()
        }
    }
}

// ---------------------------------------------------------------- memos

object Status {
    const val NEW = "new"
    const val QUEUED = "queued"
    const val WORKING = "working"
    const val DONE = "done"
    const val ERROR = "error"
}

data class Memo(
    val id: String,
    var title: String,
    val createdAt: Long,
    var durationMs: Long = 0,
    var transcript: String = "",
    var status: String = Status.NEW,
    var error: String = "",
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("title", title).put("createdAt", createdAt)
        .put("durationMs", durationMs).put("transcript", transcript)
        .put("status", status).put("error", error)

    companion object {
        fun fromJson(o: JSONObject) = Memo(
            o.getString("id"), o.optString("title"), o.optLong("createdAt"),
            o.optLong("durationMs"), o.optString("transcript"),
            o.optString("status", Status.NEW), o.optString("error"),
        )
    }
}

object MemoStore {
    private val lock = Any()

    fun dir(c: Context) = File(c.filesDir, "memos").apply { mkdirs() }
    fun audio(c: Context, id: String) = File(dir(c), "$id.wav")
    private fun meta(c: Context, id: String) = File(dir(c), "$id.json")

    fun newId(): String = System.currentTimeMillis().toString(36) + "-" + UUID.randomUUID().toString().take(6)

    fun save(c: Context, m: Memo) = synchronized(lock) {
        val tmp = File(dir(c), "${m.id}.json.tmp")
        tmp.writeText(m.toJson().toString(), Charsets.UTF_8)
        tmp.renameTo(meta(c, m.id))
    }

    fun get(c: Context, id: String): Memo? = synchronized(lock) {
        val f = meta(c, id)
        if (!f.exists()) null else try { Memo.fromJson(JSONObject(f.readText(Charsets.UTF_8))) } catch (e: Exception) { null }
    }

    fun all(c: Context): List<Memo> = synchronized(lock) {
        (dir(c).listFiles { f -> f.name.endsWith(".json") } ?: emptyArray())
            .mapNotNull { f -> try { Memo.fromJson(JSONObject(f.readText(Charsets.UTF_8))) } catch (e: Exception) { null } }
            .sortedByDescending { it.createdAt }
    }

    fun delete(c: Context, id: String) = synchronized(lock) {
        meta(c, id).delete(); audio(c, id).delete()
    }

    fun update(c: Context, id: String, block: (Memo) -> Unit) = synchronized(lock) {
        get(c, id)?.let { block(it); save(c, it) }
    }

    /** After a crash, jobs that were running/queued can never finish: mark them. */
    fun recoverStale(c: Context) {
        if (TranscribeService.running) return
        for (m in all(c)) if (m.status == Status.WORKING || m.status == Status.QUEUED) {
            m.status = Status.ERROR; m.error = "interrupted"; save(c, m)
        }
    }
}

// ---------------------------------------------------------------- WAV (16 kHz, mono, 16-bit)

const val SAMPLE_RATE = 16000

class WavWriter(private val file: File) {
    private val raf = RandomAccessFile(file, "rw")
    var dataBytes = 0L
        private set

    init {
        raf.setLength(0)
        raf.write(ByteArray(44))
    }

    fun write(pcm: ShortArray, n: Int) {
        if (n <= 0) return
        val bb = ByteBuffer.allocate(n * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (i in 0 until n) bb.putShort(pcm[i])
        raf.write(bb.array())
        dataBytes += n * 2
    }

    val durationMs get() = dataBytes / 2 * 1000 / SAMPLE_RATE

    fun close() {
        val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray()); h.putInt((36 + dataBytes).toInt())
        h.put("WAVE".toByteArray()); h.put("fmt ".toByteArray())
        h.putInt(16); h.putShort(1); h.putShort(1)
        h.putInt(SAMPLE_RATE); h.putInt(SAMPLE_RATE * 2)
        h.putShort(2); h.putShort(16)
        h.put("data".toByteArray()); h.putInt(dataBytes.toInt())
        raf.seek(0); raf.write(h.array())
        raf.close()
    }
}

object WavReader {
    /** Number of samples in one of our 16 kHz mono 16-bit WAV files. */
    fun samples(f: File): Long = maxOf(0L, (f.length() - 44) / 2)

    fun read(f: File, start: Long, count: Int): FloatArray {
        RandomAccessFile(f, "r").use { raf ->
            raf.seek(44 + start * 2)
            val bytes = ByteArray(count * 2)
            var off = 0
            while (off < bytes.size) {
                val n = raf.read(bytes, off, bytes.size - off)
                if (n < 0) break
                off += n
            }
            val got = off / 2
            val bb = ByteBuffer.wrap(bytes, 0, got * 2).order(ByteOrder.LITTLE_ENDIAN)
            return FloatArray(got) { bb.short / 32768f }
        }
    }
}

/** Streaming linear resampler to 16 kHz. */
class Resampler(inRate: Int) {
    private val step = inRate.toDouble() / SAMPLE_RATE
    private var t = 0.0
    private var base = 0L
    private var prev = 0f

    fun process(input: FloatArray, n: Int, emit: (Float) -> Unit) {
        while (true) {
            val i = floor(t).toLong()
            val idx = (i - base).toInt()
            if (idx + 1 >= n) break
            val a = if (idx < 0) prev else input[idx]
            val b = input[idx + 1]
            emit(a + (b - a) * (t - i).toFloat())
            t += step
        }
        if (n > 0) prev = input[n - 1]
        base += n
    }
}
