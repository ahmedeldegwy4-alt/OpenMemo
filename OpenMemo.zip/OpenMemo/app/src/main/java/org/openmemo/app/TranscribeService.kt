package org.openmemo.app

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import java.util.concurrent.LinkedBlockingQueue

/**
 * Runs import (decode any audio to 16 kHz WAV) and transcription jobs one by one,
 * in a foreground service so they continue when the app is in the background.
 */
class TranscribeService : Service() {

    private sealed class Job {
        data class Transcribe(val id: String) : Job()
        data class Import(val uri: Uri, val name: String) : Job()
    }

    companion object {
        private const val ACTION_TRANSCRIBE = "transcribe"
        private const val ACTION_IMPORT = "import"
        private const val ACTION_CANCEL = "cancel"
        private const val NOTIF_ID = 12
        private const val CHUNK_SAMPLES = SAMPLE_RATE * 60 * 10 // 10-minute chunks keep memory low

        @Volatile var running = false
            private set
        @Volatile var currentId: String? = null
            private set
        @Volatile var progress = 0
            private set
        @Volatile var stage = ""
            private set
        /** Last user-visible failure (shown once by the UI, then cleared). */
        @Volatile var lastError: String? = null

        fun enqueue(c: Context, memoId: String) {
            MemoStore.update(c, memoId) { it.status = Status.QUEUED; it.error = "" }
            c.startForegroundService(
                Intent(c, TranscribeService::class.java).setAction(ACTION_TRANSCRIBE).putExtra("id", memoId)
            )
        }

        fun importFile(c: Context, uri: Uri, name: String) {
            c.startForegroundService(
                Intent(c, TranscribeService::class.java).setAction(ACTION_IMPORT)
                    .setData(uri).putExtra("name", name)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        }

        fun cancel(c: Context) {
            c.startService(Intent(c, TranscribeService::class.java).setAction(ACTION_CANCEL))
        }
    }

    private val queue = LinkedBlockingQueue<Job>()
    private var worker: Thread? = null
    @Volatile private var cancelled = false
    private var ctxPtr = 0L
    private var ctxModel: String? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        goForeground()
        when (intent?.action) {
            ACTION_TRANSCRIBE -> intent?.getStringExtra("id")?.let { queue.add(Job.Transcribe(it)) }
            ACTION_IMPORT -> intent?.data?.let { queue.add(Job.Import(it, intent?.getStringExtra("name") ?: "audio")) }
            ACTION_CANCEL -> {
                cancelled = true
                WhisperLib.nativeSetAbort(true)
                for (j in queue) if (j is Job.Transcribe) MemoStore.update(this, j.id) { it.status = Status.NEW }
                queue.clear()
            }
        }
        if (worker == null) startWorker()
        return START_NOT_STICKY
    }

    private fun goForeground() {
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notif(), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIF_ID, notif())
        }
    }

    private fun notif(): Notification {
        ensureChannel(this)
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val cancel = PendingIntent.getService(
            this, 2, Intent(this, TranscribeService::class.java).setAction(ACTION_CANCEL), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(if (stage.isEmpty()) tr("جاري التحضير…", "Preparing…") else stage)
            .setProgress(100, progress, false)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(Notification.Action.Builder(null, tr("إلغاء", "Cancel"), cancel).build())
            .build()
    }

    private var lastNotif = 0L
    private fun setProgress(p: Int, force: Boolean = false) {
        progress = p
        val now = System.currentTimeMillis()
        if (force || now - lastNotif > 1000) {
            lastNotif = now
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID, notif())
        }
    }

    private val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())

    private fun startWorker() {
        running = true
        if (wakeLock == null) {
            wakeLock = (getSystemService(Context.POWER_SERVICE) as PowerManager)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "OpenMemo:stt").apply { acquire(6 * 60 * 60 * 1000L) }
        }
        worker = Thread {
            while (true) {
                val job = queue.poll() ?: break
                cancelled = false
                WhisperLib.nativeSetAbort(false)
                try {
                    when (job) {
                        is Job.Transcribe -> transcribe(job.id)
                        is Job.Import -> {
                            val id = importAudio(job.uri, job.name)
                            if (id != null && Models.active(this) != null && !cancelled) {
                                MemoStore.update(this, id) { it.status = Status.QUEUED }
                                transcribe(id)
                            }
                        }
                    }
                } catch (t: Throwable) {
                    android.util.Log.e("OpenMemo", "job failed", t)
                }
            }
            // Decide on the main thread, where new jobs are added, so none get lost.
            mainHandler.post {
                worker = null
                if (queue.isEmpty()) finish() else startWorker()
            }
        }.apply { name = "stt-worker"; start() }
    }

    private fun finish() {
        if (ctxPtr != 0L) { WhisperLib.nativeFree(ctxPtr); ctxPtr = 0L; ctxModel = null }
        currentId = null
        stage = ""
        progress = 0
        running = false
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun importAudio(uri: Uri, name: String): String? {
        val id = MemoStore.newId()
        currentId = id
        stage = tr("استيراد: ", "Importing: ") + name
        setProgress(0, true)
        val memo = Memo(id, name.substringBeforeLast('.'), System.currentTimeMillis(), status = Status.WORKING)
        MemoStore.save(this, memo)
        val err = AudioImporter.decode(this, uri, MemoStore.audio(this, id), { cancelled }) { setProgress(it) }
        if (err != null) {
            MemoStore.delete(this, id)
            if (!cancelled) lastError = tr("فشل الاستيراد: ", "Import failed: ") + err
            return null
        }
        val dur = WavReader.samples(MemoStore.audio(this, id)) * 1000 / SAMPLE_RATE
        MemoStore.update(this, id) { it.durationMs = dur; it.status = Status.NEW }
        return id
    }

    private fun transcribe(id: String) {
        val memo = MemoStore.get(this, id) ?: return
        currentId = id
        stage = tr("تحويل لنص: ", "Transcribing: ") + memo.title
        setProgress(0, true)

        val model = Models.active(this)
        if (model == null) {
            MemoStore.update(this, id) { it.status = Status.ERROR; it.error = tr("نزّل نموذج من الإعدادات", "Download a model in Settings") }
            return
        }
        if (ctxPtr == 0L || ctxModel != model.name) {
            if (ctxPtr != 0L) WhisperLib.nativeFree(ctxPtr)
            stage = tr("تحميل النموذج…", "Loading model…")
            setProgress(0, true)
            ctxPtr = WhisperLib.nativeInit(model.absolutePath)
            ctxModel = model.name
            if (ctxPtr == 0L) {
                ctxModel = null
                MemoStore.update(this, id) { it.status = Status.ERROR; it.error = tr("ملف النموذج تالف", "Model file is invalid") }
                return
            }
            stage = tr("تحويل لنص: ", "Transcribing: ") + memo.title
        }

        MemoStore.update(this, id) { it.status = Status.WORKING; it.error = "" }
        val audio = MemoStore.audio(this, id)
        val total = WavReader.samples(audio)
        if (total < SAMPLE_RATE / 2) {
            MemoStore.update(this, id) { it.status = Status.ERROR; it.error = tr("التسجيل قصير جدًا", "Recording too short") }
            return
        }
        val chunks = ((total + CHUNK_SAMPLES - 1) / CHUNK_SAMPLES).toInt()
        val lang = Prefs.language(this)
        val ts = Prefs.timestamps(this)
        val threads = Runtime.getRuntime().availableProcessors().coerceIn(2, 6)
        val sb = StringBuilder()

        for (c in 0 until chunks) {
            if (cancelled) break
            val start = c.toLong() * CHUNK_SAMPLES
            val count = minOf(CHUNK_SAMPLES.toLong(), total - start).toInt()
            val samples = WavReader.read(audio, start, count)
            val listener = object : ProgressListener {
                override fun onProgress(percent: Int) {
                    setProgress((c * 100 + percent.coerceIn(0, 100)) / chunks)
                }
            }
            val bytes = WhisperLib.nativeTranscribe(ctxPtr, samples, lang, threads, start * 1000 / SAMPLE_RATE, ts, listener)
            if (bytes == null) {
                if (!cancelled) {
                    MemoStore.update(this, id) { it.status = Status.ERROR; it.error = tr("فشل التحويل", "Transcription failed") }
                    return
                }
                break
            }
            sb.append(String(bytes, Charsets.UTF_8))
            // save partial result so long recordings show text as they go
            val partial = sb.toString().trim()
            MemoStore.update(this, id) { it.transcript = partial }
        }

        if (cancelled) {
            MemoStore.update(this, id) { it.status = Status.NEW }
        } else {
            MemoStore.update(this, id) { it.transcript = sb.toString().trim(); it.status = Status.DONE }
        }
        setProgress(100, true)
    }

    override fun onDestroy() {
        cancelled = true
        WhisperLib.nativeSetAbort(true)
        super.onDestroy()
    }
}
