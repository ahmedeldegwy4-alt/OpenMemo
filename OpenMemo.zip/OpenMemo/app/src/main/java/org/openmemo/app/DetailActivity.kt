package org.openmemo.app

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

class DetailActivity : Activity() {

    private lateinit var memo: Memo
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var titleEdit: EditText
    private lateinit var info: TextView
    private lateinit var playBtn: Button
    private lateinit var seek: SeekBar
    private lateinit var posText: TextView
    private lateinit var statusText: TextView
    private lateinit var bar: ProgressBar
    private lateinit var transcribeBtn: Button
    private lateinit var body: EditText
    private var player: MediaPlayer? = null
    private var userSeeking = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getStringExtra("id")
        val m = id?.let { MemoStore.get(this, it) }
        if (m == null) { finish(); return }
        memo = m
        title = ""

        val root = vbox(16)

        titleEdit = EditText(this).apply {
            setText(memo.title)
            textSize = 20f
            setSingleLine()
            hint = tr("العنوان", "Title")
        }
        root.addView(titleEdit, lp())
        info = text("", 13f).apply { alpha = 0.7f }
        root.addView(info, lp())

        // player
        val playRow = hbox()
        playBtn = button("▶", getColor(R.color.brand)) { togglePlay() }
        seek = SeekBar(this).apply {
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) posText.text = formatDuration(p.toLong())
                }
                override fun onStartTrackingTouch(sb: SeekBar?) { userSeeking = true }
                override fun onStopTrackingTouch(sb: SeekBar?) {
                    userSeeking = false
                    player?.seekTo(sb?.progress ?: 0)
                }
            })
        }
        posText = text("00:00", 13f)
        playRow.addView(playBtn, lp(ViewGroup.LayoutParams.WRAP_CONTENT))
        playRow.addView(seek, lp(0, weight = 1f))
        playRow.addView(posText, lp(ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(playRow, lp().margins(this, 4))

        // status + progress
        statusText = text("", 14f)
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE }
        root.addView(statusText, lp())
        root.addView(bar, lp())

        // actions
        val actions = hbox()
        transcribeBtn = button(tr("حوّل لنص", "Transcribe"), getColor(R.color.accent)) { transcribe() }
        actions.addView(transcribeBtn, lp(ViewGroup.LayoutParams.WRAP_CONTENT).margins(this, 4))
        actions.addView(button(tr("حفظ", "Save"), getColor(R.color.brand)) { save(true) }, lp(ViewGroup.LayoutParams.WRAP_CONTENT).margins(this, 4))
        actions.addView(button(tr("نسخ", "Copy"), getColor(R.color.brand)) { copy() }, lp(ViewGroup.LayoutParams.WRAP_CONTENT).margins(this, 4))
        actions.addView(button(tr("مشاركة النص", "Share text"), getColor(R.color.brand)) { shareText() }, lp(ViewGroup.LayoutParams.WRAP_CONTENT).margins(this, 4))
        actions.addView(button(tr("مشاركة الصوت", "Share audio"), getColor(R.color.brand)) { shareAudio() }, lp(ViewGroup.LayoutParams.WRAP_CONTENT).margins(this, 4))
        val actionsScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(actions) }
        root.addView(actionsScroll, lp())

        // transcript
        body = EditText(this).apply {
            setText(memo.transcript)
            gravity = Gravity.TOP or Gravity.START
            textSize = 17f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            setSingleLine(false)
            minLines = 8
            hint = tr("النص هيظهر هنا بعد التحويل", "Transcript appears here")
            setLineSpacing(0f, 1.25f)
            textAlignment = View.TEXT_ALIGNMENT_GRAVITY
        }
        val scroll = ScrollView(this).apply { addView(body) }
        root.addView(scroll, lp(h = 0, weight = 1f))

        setContentView(root)
        bindStatus()
    }

    override fun onResume() {
        super.onResume()
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
        player?.let { if (it.isPlaying) it.pause() }
        save(false)
    }

    override fun onDestroy() {
        super.onDestroy()
        player?.release()
        player = null
    }

    private val tick = object : Runnable {
        override fun run() {
            bindStatus()
            player?.let { p ->
                if (!userSeeking) {
                    seek.progress = p.currentPosition
                    posText.text = formatDuration(p.currentPosition.toLong())
                }
                playBtn.text = if (p.isPlaying) "❚❚" else "▶"
            }
            handler.postDelayed(this, 300)
        }
    }

    private fun busy(): Boolean = TranscribeService.running && TranscribeService.currentId == memo.id

    private var wasBusy = false

    private fun bindStatus() {
        val fresh = MemoStore.get(this, memo.id) ?: return
        val isBusy = busy() || fresh.status == Status.QUEUED
        info.text = formatDate(fresh.createdAt) + "  •  " + formatDuration(fresh.durationMs)
        if (isBusy) {
            statusText.text = if (fresh.status == Status.QUEUED && !busy()) tr("في الانتظار…", "Queued…")
            else TranscribeService.stage + "  " + TranscribeService.progress + "%"
            bar.visibility = View.VISIBLE
            bar.progress = TranscribeService.progress
            transcribeBtn.text = tr("إلغاء", "Cancel")
            body.isEnabled = false
            if (fresh.transcript != body.text.toString()) body.setText(fresh.transcript)
        } else {
            statusText.text = statusLabel(fresh)
            bar.visibility = View.GONE
            transcribeBtn.text = if (fresh.transcript.isBlank()) tr("حوّل لنص", "Transcribe") else tr("إعادة التحويل", "Re-transcribe")
            body.isEnabled = true
            if (wasBusy) {
                // job just finished: show final text
                body.setText(fresh.transcript)
                memo.transcript = fresh.transcript
            }
        }
        memo.status = fresh.status
        memo.durationMs = fresh.durationMs
        wasBusy = isBusy
    }

    private fun transcribe() {
        if (busy() || memo.status == Status.QUEUED) {
            TranscribeService.cancel(this); return
        }
        if (Models.active(this) == null) {
            Toast.makeText(this, tr("نزّل نموذج من الإعدادات الأول", "Download a model in Settings first"), Toast.LENGTH_LONG).show()
            startActivity(Intent(this, SettingsActivity::class.java))
            return
        }
        val go = {
            save(false)
            TranscribeService.enqueue(this, memo.id)
            memo.status = Status.QUEUED
            bindStatus()
        }
        if (body.text.isNotBlank()) {
            AlertDialog.Builder(this)
                .setMessage(tr("النص الحالي هيتستبدل. تكمل؟", "The current text will be replaced. Continue?"))
                .setPositiveButton(tr("أيوه", "Yes")) { _, _ -> go() }
                .setNegativeButton(tr("لا", "No"), null).show()
        } else go()
    }

    private fun save(toast: Boolean) {
        if (!::memo.isInitialized || busy()) return
        val t = titleEdit.text.toString().trim().ifEmpty { memo.title }
        val b = body.text.toString()
        MemoStore.update(this, memo.id) {
            it.title = t
            if (it.status != Status.WORKING && it.status != Status.QUEUED) it.transcript = b
        }
        memo.title = t
        if (toast) Toast.makeText(this, tr("اتحفظ", "Saved"), Toast.LENGTH_SHORT).show()
    }

    private fun togglePlay() {
        val p = player ?: try {
            MediaPlayer().apply {
                setDataSource(MemoStore.audio(this@DetailActivity, memo.id).absolutePath)
                prepare()
                seek.max = duration
                setOnCompletionListener { playBtn.text = "▶" }
            }.also { player = it }
        } catch (e: Exception) {
            Toast.makeText(this, e.message ?: "error", Toast.LENGTH_SHORT).show(); return
        }
        if (p.isPlaying) p.pause() else p.start()
    }

    private fun plainText(): String = body.text.toString()

    private fun copy() {
        val cm = getSystemService(ClipboardManager::class.java)
        cm.setPrimaryClip(ClipData.newPlainText(memo.title, plainText()))
        Toast.makeText(this, tr("اتنسخ", "Copied"), Toast.LENGTH_SHORT).show()
    }

    private fun shareText() {
        startActivity(Intent.createChooser(
            Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_SUBJECT, titleEdit.text.toString())
                .putExtra(Intent.EXTRA_TEXT, plainText()), null))
    }

    private fun shareAudio() {
        val src = MemoStore.audio(this, memo.id)
        if (!src.exists()) return
        // copy with a readable name so it arrives as "<title>.wav"
        val dir = File(cacheDir, "export").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() }
        val safe = titleEdit.text.toString().replace(Regex("[\\\\/:*?\"<>|]"), "_").take(60).ifBlank { "memo" }
        val f = File(dir, "$safe.wav")
        src.copyTo(f, overwrite = true)
        val uri = FileProvider.getUriForFile(this, "$packageName.files", f)
        startActivity(Intent.createChooser(
            Intent(Intent.ACTION_SEND).setType("audio/wav").putExtra(Intent.EXTRA_STREAM, uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), null))
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(0, 1, 0, tr("حذف", "Delete"))
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == 1) {
            AlertDialog.Builder(this)
                .setMessage(tr("حذف التسجيل والنص نهائيًا؟", "Delete recording and text permanently?"))
                .setPositiveButton(tr("حذف", "Delete")) { _, _ ->
                    if (busy()) TranscribeService.cancel(this)
                    player?.release(); player = null
                    MemoStore.delete(this, memo.id)
                    finish()
                }
                .setNegativeButton(tr("لا", "No"), null).show()
        }
        return true
    }
}

