package org.openmemo.app

import android.annotation.SuppressLint
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import kotlin.math.sqrt

/** Records 16 kHz mono WAV in a foreground service so lectures keep recording with the screen off. */
class RecorderService : Service() {

    companion object {
        const val ACTION_START = "start"
        const val ACTION_PAUSE = "pause"
        const val ACTION_RESUME = "resume"
        const val ACTION_STOP = "stop"
        private const val NOTIF_ID = 11

        @Volatile var recording = false
            private set
        @Volatile var paused = false
            private set
        @Volatile var elapsedMs = 0L
            private set
        @Volatile var level = 0f
            private set          // 0..1 for the meter
        @Volatile var memoId: String? = null
            private set
        @Volatile var lastError: String? = null

        fun send(c: Context, action: String) {
            val i = Intent(c, RecorderService::class.java).setAction(action)
            if (action == ACTION_START) c.startForegroundService(i) else c.startService(i)
        }
    }

    private var thread: Thread? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> start()
            ACTION_PAUSE -> { paused = true; updateNotif() }
            ACTION_RESUME -> { paused = false; updateNotif() }
            ACTION_STOP -> stopRecording()
        }
        return START_NOT_STICKY
    }

    private fun notif(): Notification {
        ensureChannel(this)
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, RecorderService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val text = if (paused) tr("متوقف مؤقتًا", "Paused") else tr("جاري التسجيل…", "Recording…")
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("OpenMemo")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setUsesChronometer(!paused)
            .addAction(Notification.Action.Builder(null, tr("إيقاف", "Stop"), stop).build())
            .build()
    }

    private fun updateNotif() {
        if (recording) getSystemService(android.app.NotificationManager::class.java).notify(NOTIF_ID, notif())
    }

    @SuppressLint("MissingPermission")
    private fun start() {
        if (recording) return
        val id = MemoStore.newId()
        val memo = Memo(id, tr("تسجيل ", "Recording ") + formatDate(System.currentTimeMillis()), System.currentTimeMillis())

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notif(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, notif())
        }

        val minBuf = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val bufSize = maxOf(minBuf, SAMPLE_RATE / 5 * 2)
        val rec = try {
            AudioRecord(MediaRecorder.AudioSource.MIC, SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufSize * 2)
        } catch (e: Exception) {
            lastError = e.message; stopSelfClean(); return
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            lastError = tr("الميكروفون مش متاح", "Microphone not available")
            rec.release(); stopSelfClean(); return
        }

        MemoStore.save(this, memo)
        memoId = id
        recording = true
        paused = false
        elapsedMs = 0
        lastError = null

        wakeLock = (getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "OpenMemo:rec").apply { acquire(6 * 60 * 60 * 1000L) }

        val file = MemoStore.audio(this, id)
        thread = Thread {
            val writer = WavWriter(file)
            val buf = ShortArray(bufSize / 2)
            try {
                rec.startRecording()
                while (recording) {
                    val n = rec.read(buf, 0, buf.size)
                    if (n <= 0) continue
                    if (!paused) {
                        writer.write(buf, n)
                        elapsedMs = writer.durationMs
                    }
                    var sum = 0.0
                    for (i in 0 until n) { val v = buf[i] / 32768.0; sum += v * v }
                    level = minOf(1f, (sqrt(sum / n) * 4).toFloat())
                }
            } catch (e: Exception) {
                lastError = e.message
            } finally {
                try { rec.stop() } catch (_: Exception) {}
                rec.release()
                writer.close()
                MemoStore.update(this, id) { it.durationMs = writer.durationMs }
            }
        }.apply { name = "recorder"; start() }
    }

    private fun stopRecording() {
        val id = memoId
        recording = false
        thread?.join(3000)
        thread = null
        level = 0f
        if (id != null) {
            val m = MemoStore.get(this, id)
            if (m != null && m.durationMs < 500) {
                MemoStore.delete(this, id) // nothing recorded
            } else if (m != null && Prefs.autoTranscribe(this) && Models.active(this) != null) {
                TranscribeService.enqueue(this, id)
            }
        }
        memoId = null
        stopSelfClean()
    }

    private fun stopSelfClean() {
        recording = false
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        if (recording) {
            recording = false
            thread?.join(3000)
        }
        wakeLock?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }
}
