package org.openmemo.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Toast

class SettingsActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var modelsBox: LinearLayout
    @Volatile private var downloading: String? = null
    @Volatile private var cancelDownload = false
    @Volatile private var dlProgress = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = tr("الإعدادات", "Settings")
        val root = vbox(16)

        // ---- language
        root.addView(text(tr("لغة الكلام", "Spoken language"), 18f, true), lp())
        val langs = listOf(
            "auto" to tr("تلقائي (يكتشف اللغة)", "Auto-detect"),
            "ar" to "العربية",
            "en" to "English",
        )
        val group = RadioGroup(this)
        val current = Prefs.language(this)
        langs.forEachIndexed { i, (code, label) ->
            group.addView(RadioButton(this).apply {
                id = 100 + i
                text = label
                isChecked = code == current
            })
        }
        group.setOnCheckedChangeListener { _, checkedId ->
            langs.getOrNull(checkedId - 100)?.let { Prefs.setLanguage(this, it.first) }
        }
        root.addView(group, lp())
        root.addView(text(tr("اختيار اللغة بدل التلقائي بيدّي نتيجة أدق، خصوصًا للعربي.",
            "Choosing the language (instead of auto) gives better accuracy."), 13f).apply { alpha = 0.7f }, lp())

        // ---- options
        root.addView(space(), lp())
        root.addView(CheckBox(this).apply {
            text = tr("حوّل لنص تلقائيًا بعد التسجيل", "Transcribe automatically after recording")
            isChecked = Prefs.autoTranscribe(this@SettingsActivity)
            setOnCheckedChangeListener { _, v -> Prefs.setAutoTranscribe(this@SettingsActivity, v) }
        }, lp())
        root.addView(CheckBox(this).apply {
            text = tr("اكتب التوقيت جنب كل جملة [00:12]", "Add timestamps to each line [00:12]")
            isChecked = Prefs.timestamps(this@SettingsActivity)
            setOnCheckedChangeListener { _, v -> Prefs.setTimestamps(this@SettingsActivity, v) }
        }, lp())

        // ---- models
        root.addView(space(), lp())
        root.addView(text(tr("نموذج التحويل لنص", "Speech model"), 18f, true), lp())
        root.addView(text(tr(
            "بيتنزل مرة واحدة بس، وبعد كده التطبيق يشتغل من غير إنترنت.\nالأكبر = أدق بس أبطأ.",
            "Downloaded once; after that everything works offline.\nBigger = more accurate but slower."), 13f).apply { alpha = 0.7f }, lp())
        modelsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(modelsBox, lp())
        root.addView(button(tr("استيراد ملف نموذج (.bin) من الموبايل", "Import a model file (.bin)"), Color.GRAY) {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), 20)
        }, lp().margins(this, 6))

        root.addView(space(), lp())
        root.addView(text("CPU: " + try { WhisperLib.nativeSystemInfo() } catch (e: Throwable) { "?" }, 11f).apply { alpha = 0.5f }, lp())

        setContentView(ScrollView(this).apply { addView(root) })
        buildModels()
    }

    private fun space() = View(this).apply { minimumHeight = dp(16) }

    private fun buildModels() {
        modelsBox.removeAllViews()
        val active = Models.active(this)?.name
        val known = Models.list.map { it.file }.toSet()
        for (m in Models.list) {
            val f = Models.file(this, m.file)
            val card = vbox(12).apply { background = pill(0x14808080, 12) }
            val label = (if (isArabic()) m.labelAr else m.labelEn) + "  (${m.sizeMb} MB)"
            card.addView(text(label, 16f, m.file == active), lp())
            val row = hbox()
            when {
                downloading == m.file -> {
                    val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; progress = dlProgress; tag = "bar" }
                    row.addView(bar, lp(0, weight = 1f))
                    row.addView(button(tr("إلغاء", "Cancel"), Color.GRAY) { cancelDownload = true }, lp(ViewGroup.LayoutParams.WRAP_CONTENT).margins(this, 4))
                }
                f.exists() -> {
                    if (m.file == active) row.addView(text(tr("✓ مستخدم حاليًا", "✓ In use"), 14f, true), lp(0, weight = 1f))
                    else {
                        row.addView(View(this), lp(0, weight = 1f))
                        row.addView(button(tr("استخدم", "Use"), getColor(R.color.brand)) { Prefs.setModel(this, m.file); buildModels() },
                            lp(ViewGroup.LayoutParams.WRAP_CONTENT).margins(this, 4))
                    }
                    row.addView(button(tr("حذف", "Delete"), Color.GRAY) { deleteModel(m.file) },
                        lp(ViewGroup.LayoutParams.WRAP_CONTENT).margins(this, 4))
                }
                else -> {
                    row.addView(View(this), lp(0, weight = 1f))
                    row.addView(button(tr("تنزيل", "Download"), getColor(R.color.accent)) { download(m) },
                        lp(ViewGroup.LayoutParams.WRAP_CONTENT).margins(this, 4))
                }
            }
            card.addView(row, lp())
            modelsBox.addView(card, lp().margins(this, 4))
        }
        // imported custom models
        for (f in Models.installed(this).filter { it.name !in known }) {
            val card = vbox(12).apply { background = pill(0x14808080, 12) }
            card.addView(text(f.name + "  (${f.length() / 1_000_000} MB)", 16f, f.name == active), lp())
            val row = hbox()
            row.addView(View(this), lp(0, weight = 1f))
            if (f.name != active) row.addView(button(tr("استخدم", "Use"), getColor(R.color.brand)) { Prefs.setModel(this, f.name); buildModels() },
                lp(ViewGroup.LayoutParams.WRAP_CONTENT).margins(this, 4))
            row.addView(button(tr("حذف", "Delete"), Color.GRAY) { deleteModel(f.name) }, lp(ViewGroup.LayoutParams.WRAP_CONTENT).margins(this, 4))
            card.addView(row, lp())
            modelsBox.addView(card, lp().margins(this, 4))
        }
    }

    private fun deleteModel(name: String) {
        if (TranscribeService.running) {
            Toast.makeText(this, tr("استنى لما التحويل يخلص", "Wait for transcription to finish"), Toast.LENGTH_SHORT).show(); return
        }
        Models.file(this, name).delete()
        if (Prefs.model(this) == name) Prefs.setModel(this, null)
        buildModels()
    }

    private fun download(m: ModelInfo) {
        if (downloading != null) return
        downloading = m.file
        cancelDownload = false
        dlProgress = 0
        buildModels()
        Thread {
            val err = Models.download(this, m, { cancelDownload }) { p ->
                dlProgress = p
                handler.post { (modelsBox.findViewWithTag<ProgressBar>("bar"))?.progress = p }
            }
            handler.post {
                downloading = null
                if (err == null) {
                    Prefs.setModel(this, m.file)
                    Toast.makeText(this, tr("تم التنزيل ✓", "Downloaded ✓"), Toast.LENGTH_SHORT).show()
                } else if (err != "cancelled") {
                    Toast.makeText(this, tr("فشل التنزيل: ", "Download failed: ") + err, Toast.LENGTH_LONG).show()
                }
                if (!isDestroyed) buildModels()
            }
        }.start()
    }

    override fun onDestroy() {
        cancelDownload = true
        super.onDestroy()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 20 || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        var name = displayName(uri).replace(Regex("[^A-Za-z0-9._-]"), "_")
        if (!name.endsWith(".bin")) name += ".bin"
        val dst = Models.file(this, name)
        Toast.makeText(this, tr("جاري النسخ…", "Copying…"), Toast.LENGTH_SHORT).show()
        Thread {
            val ok = try {
                contentResolver.openInputStream(uri)!!.use { i -> dst.outputStream().use { o -> i.copyTo(o, 1 shl 16) } }
                true
            } catch (e: Exception) { dst.delete(); false }
            handler.post {
                if (ok) Prefs.setModel(this, name)
                Toast.makeText(this, if (ok) tr("تم ✓", "Done ✓") else tr("فشل النسخ", "Copy failed"), Toast.LENGTH_SHORT).show()
                if (!isDestroyed) buildModels()
            }
        }.start()
    }
}

