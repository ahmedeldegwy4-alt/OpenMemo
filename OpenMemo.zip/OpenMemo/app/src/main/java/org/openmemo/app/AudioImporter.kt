package org.openmemo.app

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.io.File
import java.nio.ByteOrder

/** Decodes any audio/video file Android can read (mp3, m4a, ogg/opus, wav, mp4…) to 16 kHz mono WAV. */
object AudioImporter {

    /** Returns null on success, or an error message. */
    fun decode(c: Context, uri: Uri, out: File, cancelled: () -> Boolean, progress: (Int) -> Unit): String? {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        var writer: WavWriter? = null
        try {
            ex.setDataSource(c, uri, null)
            var track = -1
            for (i in 0 until ex.trackCount) {
                val mime = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) { track = i; break }
            }
            if (track < 0) return c.tr("مفيش صوت في الملف", "No audio track found")
            ex.selectTrack(track)
            val fmt = ex.getTrackFormat(track)
            val mime = fmt.getString(MediaFormat.KEY_MIME)!!
            val durationUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else 0L

            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(fmt, null, null, 0)
            codec.start()
            val w = WavWriter(out)
            writer = w

            var channels = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            var rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var resampler = Resampler(rate)
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var mono = FloatArray(8192)
            val outBuf = ShortArray(8192)
            var outN = 0
            val flush = {
                w.write(outBuf, outN); outN = 0
            }

            while (!outputDone) {
                if (cancelled()) return "cancelled"
                if (!inputDone) {
                    val inIdx = codec.dequeueInputBuffer(10_000)
                    if (inIdx >= 0) {
                        val buf = codec.getInputBuffer(inIdx)!!
                        val size = ex.readSampleData(buf, 0)
                        if (size < 0) {
                            codec.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            val t = ex.sampleTime
                            codec.queueInputBuffer(inIdx, 0, size, t, 0)
                            ex.advance()
                            if (durationUs > 0) progress((t * 100 / durationUs).toInt().coerceIn(0, 99))
                        }
                    }
                }
                val outIdx = codec.dequeueOutputBuffer(info, 10_000)
                when {
                    outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val of = codec.outputFormat
                        channels = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        val newRate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        if (newRate != rate) { rate = newRate; resampler = Resampler(rate) }
                    }
                    outIdx >= 0 -> {
                        if (info.size > 0) {
                            val bb = codec.getOutputBuffer(outIdx)!!
                            bb.position(info.offset)
                            bb.limit(info.offset + info.size)
                            val sb = bb.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                            val frames = sb.remaining() / channels
                            if (mono.size < frames) mono = FloatArray(frames)
                            for (f in 0 until frames) {
                                var s = 0f
                                for (ch in 0 until channels) s += sb.get()
                                mono[f] = s / channels / 32768f
                            }
                            resampler.process(mono, frames) { v ->
                                outBuf[outN++] = (v.coerceIn(-1f, 1f) * 32767f).toInt().toShort()
                                if (outN == outBuf.size) flush()
                            }
                        }
                        codec.releaseOutputBuffer(outIdx, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                    }
                }
            }
            flush()
            progress(100)
            return null
        } catch (e: Exception) {
            return e.message ?: e.toString()
        } finally {
            try { codec?.stop() } catch (_: Exception) {}
            codec?.release()
            ex.release()
            try { writer?.close() } catch (_: Exception) {}
        }
    }
}
