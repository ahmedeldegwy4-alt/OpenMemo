package org.openmemo.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var list: ListView
    private lateinit var search: EditText
    private lateinit var banner: TextView
    private lateinit var recPanel: LinearLayout
    private lateinit var recTime: TextView
    private lateinit var recLevel: ProgressBar
    private lateinit var pauseBtn: Button
    private lateinit var workPanel: LinearLayout
    private lateinit var workText: TextView
    private lateinit var workBar: ProgressBar
    private lateinit var recordBtn: Button
    private val adapter = MemoAdapter()
    private var memos: List<Memo> = emptyList()
    private var lastRefresh = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MemoStore.recoverStale(this)

        val root = vbox(0)

        banner = text(tr("⬇ لازم تنزّل نموذج التحويل لنص مرة واحدة — اضغط هنا",
            "⬇ Download a speech model once — tap here"), 15f, true).apply {
            setBackgroundColor(getColor(R.color.accent))
            setTextColor(Color.WHITE)
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        }
        root.addView(banner, lp())

        search = EditText(this).apply {
            hint = tr("بحث في التسجيلات والنصوص", "Search recordings and text")
            setSingleLine()
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) = refresh()
            })
        }
        root.addView(search, lp().margins(this, 8))

        val empty = text(tr("لسه مفيش تسجيلات.\nاضغط زر التسجيل تحت للبدء.",
            "No recordings yet.\nTap the record button below."), 16f).apply {
            gravity = Gravity.CENTER
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            setPadding(dp(24), dp(48), dp(24), dp(48))
        }
        list = ListView(this).apply {
            adapter = this@MainActivity.adapter
            setOnItemClickListener { _, _, pos, _ ->
                startActivity(Intent(this@MainActivity, DetailActivity::class.java).putExtra("id", memos[pos].id))
            }
        }
        val listBox = android.widget.FrameLayout(this)
        listBox.addView(list)
        listBox.addView(empty)
        list.emptyView = empty
        root.addView(listBox, lp(h = 0, weight = 1f))

        // transcription progress
        workPanel = vbox(12).apply { visibility = View.GONE }
        workText = text("", 14f)
        workBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        val workRow = hbox()
        workRow.addView(workBar, lp(0, weight = 1f))
        workRow.addView(button(tr("إلغاء", "Cancel"), Color.GRAY) { TranscribeService.cancel(this) }, lp(ViewGroup.LayoutParams.WRAP_CONTENT).margins(this, 4))
        workPanel.addView(workText)
        workPanel.addView(workRow, lp())
        root.addView(workPanel, lp())

        // recording panel
        recPanel = vbox(16).apply { visibility = View.GONE; gravity = Gravity.CENTER_HORIZONTAL }
        recTime = text("00:00", 44f, true).apply { gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER }
        recLevel = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        pauseBtn = button(tr("إيقاف مؤقت", "Pause"), Color.GRAY) {
            RecorderService.send(this, if (RecorderService.paused) RecorderService.ACTION_RESUME else RecorderService.ACTION_PAUSE)
        }
        val stopBtn = button(tr("إنهاء وحفظ", "Stop & save"), getColor(R.color.accent)) {
            RecorderService.send(this, RecorderService.ACTION_STOP)
        }
        val recRow = hbox().apply { gravity = Gravity.CENTER }
        recRow.addView(pauseBtn, lp(0, weight = 1f).margins(this, 6))
        recRow.addView(stopBtn, lp(0, weight = 1f).margins(this, 6))
        recPanel.addView(recTime, lp())
        recPanel.addView(recLevel, lp())
        recPanel.addView(recRow, lp())
        root.addView(recPanel, lp())

        recordBtn = button("●  " + tr("تسجيل جديد", "New recording"), getColor(R.color.brand)) { startRecordingChecked() }.apply {
            textSize = 18f
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        root.addView(recordBtn, lp().margins(this, 12))

        setContentView(root)
        handleShare(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        intent?.let { handleShare(it) }
    }

    @Suppress("DEPRECATION")
    private fun handleShare(i: Intent) {
        if (i.action != Intent.ACTION_SEND) return
        val uri = i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM) ?: return
        TranscribeService.importFile(this, uri, displayName(uri))
        Toast.makeText(this, tr("جاري الاستيراد…", "Importing…"), Toast.LENGTH_SHORT).show()
        i.action = null
    }

    override fun onResume() {
        super.onResume()
        refresh()
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    private val tick = object : Runnable {
        override fun run() {
            updateLive()
            handler.postDelayed(this, 250)
        }
    }

    private fun updateLive() {
        val rec = RecorderService.recording
        recPanel.visibility = if (rec) View.VISIBLE else View.GONE
        recordBtn.visibility = if (rec) View.GONE else View.VISIBLE
        if (rec) {
            recTime.text = formatDuration(RecorderService.elapsedMs)
            recLevel.progress = (RecorderService.level * 100).toInt()
            pauseBtn.text = if (RecorderService.paused) tr("استكمال", "Resume") else tr("إيقاف مؤقت", "Pause")
        }
        RecorderService.lastError?.let {
            Toast.makeText(this, it, Toast.LENGTH_LONG).show(); RecorderService.lastError = null
        }
        TranscribeService.lastError?.let {
            Toast.makeText(this, it, Toast.LENGTH_LONG).show(); TranscribeService.lastError = null
        }

        val work = TranscribeService.running
        workPanel.visibility = if (work) View.VISIBLE else View.GONE
        if (work) {
            workText.text = TranscribeService.stage + "  " + TranscribeService.progress + "%"
            workBar.progress = TranscribeService.progress
        }
        banner.visibility = if (Models.active(this) == null) View.VISIBLE else View.GONE

        val now = System.currentTimeMillis()
        if ((work || rec) && now - lastRefresh > 1500) refresh()
        else if (!work && !rec && memos.any { it.status == Status.WORKING || it.status == Status.QUEUED } && now - lastRefresh > 1500) refresh()
    }

    private fun refresh() {
        lastRefresh = System.currentTimeMillis()
        val q = if (::search.isInitialized) search.text.toString().trim() else ""
        val all = MemoStore.all(this).filter { it.id != RecorderService.memoId }
        memos = if (q.isEmpty()) all else all.filter {
            it.title.contains(q, ignoreCase = true) || it.transcript.contains(q, ignoreCase = true)
        }
        adapter.notifyDataSetChanged()
    }

    // ------------------------------------------------------------ recording permission

    private fun startRecordingChecked() {
        val need = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isEmpty()) startRecording() else requestPermissions(need.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1) {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startRecording()
            else Toast.makeText(this, tr("لازم تسمح باستخدام الميكروفون", "Microphone permission is required"), Toast.LENGTH_LONG).show()
        }
    }

    private fun startRecording() {
        RecorderService.send(this, RecorderService.ACTION_START)
    }

    // ------------------------------------------------------------ menu / import

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(0, 1, 0, tr("استيراد ملف صوتي", "Import audio file"))
        menu.add(0, 2, 1, tr("الإعدادات", "Settings"))
        menu.add(0, 3, 2, tr("عن التطبيق", "About"))
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            1 -> startActivityForResult(
                Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
                    .putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("audio/*", "video/*")), 10
            )
            2 -> startActivity(Intent(this, SettingsActivity::class.java))
            3 -> AlertDialog.Builder(this)
                .setTitle("OpenMemo 1.0")
                .setMessage(tr(
                    "تطبيق مفتوح المصدر لتسجيل الصوت وتحويله لنص على الموبايل نفسه.\nمفيش حساب ولا اشتراك، والصوت ما بيخرجش من جهازك.\n\nمبني على whisper.cpp (رخصة MIT).",
                    "Open-source recorder with on-device speech-to-text.\nNo account, no subscription, audio never leaves your phone.\n\nPowered by whisper.cpp (MIT)."))
                .setPositiveButton("OK", null).show()
        }
        return true
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 10 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            TranscribeService.importFile(this, uri, displayName(uri))
            Toast.makeText(this, tr("جاري الاستيراد…", "Importing…"), Toast.LENGTH_SHORT).show()
        }
    }

    // ------------------------------------------------------------ list

    inner class MemoAdapter : BaseAdapter() {
        override fun getCount() = memos.size
        override fun getItem(position: Int) = memos[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val m = memos[position]
            val box = (convertView as? LinearLayout) ?: vbox(14).apply {
                addView(text("", 17f, true).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
                addView(text("", 13f).apply { alpha = 0.7f })
                addView(text("", 14f).apply { maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END })
            }
            (box.getChildAt(0) as TextView).text = m.title
            (box.getChildAt(1) as TextView).text =
                formatDate(m.createdAt) + "  •  " + formatDuration(m.durationMs) + "  •  " + statusLabel(m)
            val preview = m.transcript.replace(Regex("\\[[0-9:]+\\] "), "").replace('\n', ' ')
            (box.getChildAt(2) as TextView).apply {
                text = preview
                visibility = if (preview.isBlank()) View.GONE else View.VISIBLE
            }
            return box
        }
    }
}
