// JNI bridge between the Kotlin app and whisper.cpp (on-device speech-to-text).
#include <jni.h>
#include <atomic>
#include <cstdio>
#include <string>

#ifdef __ANDROID__
#include <android/log.h>
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "OpenMemo", __VA_ARGS__)
#else
#define LOGI(...) fprintf(stderr, __VA_ARGS__)
#endif

#include "whisper.h"

static std::atomic<bool> g_abort(false);

struct ProgressCtx {
    JNIEnv *env;
    jobject listener;
    jmethodID method;
};

static void on_progress(struct whisper_context *, struct whisper_state *, int progress, void *user_data) {
    auto *p = static_cast<ProgressCtx *>(user_data);
    if (p != nullptr && p->listener != nullptr && p->method != nullptr) {
        p->env->CallVoidMethod(p->listener, p->method, (jint) progress);
        if (p->env->ExceptionCheck()) p->env->ExceptionClear();
    }
}

static bool on_abort(void *) {
    return g_abort.load();
}

static void format_time(int64_t ms, char *buf, size_t len) {
    int64_t s = ms / 1000;
    int64_t h = s / 3600;
    int64_t m = (s % 3600) / 60;
    int64_t sec = s % 60;
    if (h > 0) snprintf(buf, len, "%lld:%02lld:%02lld", (long long) h, (long long) m, (long long) sec);
    else snprintf(buf, len, "%02lld:%02lld", (long long) m, (long long) sec);
}

extern "C" {

JNIEXPORT jlong JNICALL
Java_org_openmemo_app_WhisperLib_nativeInit(JNIEnv *env, jobject, jstring jpath) {
    const char *path = env->GetStringUTFChars(jpath, nullptr);
    struct whisper_context_params cparams = whisper_context_default_params();
    cparams.use_gpu = false;
    struct whisper_context *ctx = whisper_init_from_file_with_params(path, cparams);
    LOGI("model load %s -> %p", path, (void *) ctx);
    env->ReleaseStringUTFChars(jpath, path);
    return (jlong) ctx;
}

JNIEXPORT void JNICALL
Java_org_openmemo_app_WhisperLib_nativeFree(JNIEnv *, jobject, jlong ptr) {
    if (ptr != 0) whisper_free(reinterpret_cast<struct whisper_context *>(ptr));
}

JNIEXPORT void JNICALL
Java_org_openmemo_app_WhisperLib_nativeSetAbort(JNIEnv *, jobject, jboolean value) {
    g_abort.store(value == JNI_TRUE);
}

JNIEXPORT jstring JNICALL
Java_org_openmemo_app_WhisperLib_nativeSystemInfo(JNIEnv *env, jobject) {
    return env->NewStringUTF(whisper_print_system_info());
}

// Returns UTF-8 bytes: one line per segment, "[mm:ss] text". null on failure/abort.
JNIEXPORT jbyteArray JNICALL
Java_org_openmemo_app_WhisperLib_nativeTranscribe(JNIEnv *env, jobject, jlong ptr, jfloatArray jsamples,
                                                   jstring jlang, jint threads, jlong offset_ms,
                                                   jboolean timestamps, jobject listener) {
    auto *ctx = reinterpret_cast<struct whisper_context *>(ptr);
    if (ctx == nullptr) return nullptr;

    const char *lang = env->GetStringUTFChars(jlang, nullptr);
    std::string language(lang);
    env->ReleaseStringUTFChars(jlang, lang);

    jsize n = env->GetArrayLength(jsamples);
    jfloat *samples = env->GetFloatArrayElements(jsamples, nullptr);

    struct whisper_full_params params = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
    params.print_realtime = false;
    params.print_progress = false;
    params.print_timestamps = false;
    params.print_special = false;
    params.translate = false;
    params.language = language.c_str();
    params.n_threads = threads > 0 ? threads : 4;
    params.no_context = true;

    ProgressCtx pctx{env, listener, nullptr};
    if (listener != nullptr) {
        jclass cls = env->GetObjectClass(listener);
        pctx.method = env->GetMethodID(cls, "onProgress", "(I)V");
        env->DeleteLocalRef(cls);
        params.progress_callback = on_progress;
        params.progress_callback_user_data = &pctx;
    }
    params.abort_callback = on_abort;
    params.abort_callback_user_data = nullptr;

    int rc = whisper_full(ctx, params, samples, n);
    env->ReleaseFloatArrayElements(jsamples, samples, JNI_ABORT);
    if (rc != 0 || g_abort.load()) {
        LOGI("whisper_full failed rc=%d abort=%d", rc, (int) g_abort.load());
        return nullptr;
    }

    std::string out;
    const int segs = whisper_full_n_segments(ctx);
    char tbuf[32];
    for (int i = 0; i < segs; ++i) {
        const char *text = whisper_full_get_segment_text(ctx, i);
        if (text == nullptr) continue;
        std::string t(text);
        size_t a = t.find_first_not_of(" \t\n");
        if (a == std::string::npos) continue;
        t = t.substr(a);
        if (timestamps == JNI_TRUE) {
            int64_t t0 = whisper_full_get_segment_t0(ctx, i) * 10 + offset_ms;  // t0 is in 10 ms units
            format_time(t0, tbuf, sizeof(tbuf));
            out += "[";
            out += tbuf;
            out += "] ";
        }
        out += t;
        out += "\n";
    }

    jbyteArray result = env->NewByteArray((jsize) out.size());
    env->SetByteArrayRegion(result, 0, (jsize) out.size(), reinterpret_cast<const jbyte *>(out.data()));
    return result;
}

}  // extern "C"
